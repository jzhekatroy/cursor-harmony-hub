import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { hashPassword, generateToken } from '@/lib/auth'

// Функция генерации номера команды
function generateTeamNumber(): string {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  const numbers = '0123456789'
  
  let result = ''
  result += letters.charAt(Math.floor(Math.random() * letters.length))
  
  for (let i = 0; i < 8; i++) {
    result += numbers.charAt(Math.floor(Math.random() * numbers.length))
  }
  
  return result
}

// Функция генерации slug
function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-zA-Z0-9а-яё\s]/g, '')
    .replace(/\s+/g, '-')
    .replace(/[а-я]/g, (match) => {
      const map: { [key: string]: string } = {
        'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'e',
        'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
        'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
        'ф': 'f', 'х': 'h', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch',
        'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya'
      }
      return map[match] || match
    })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { teamName, contactPerson, email, password } = body

    // Валидация
    if (!teamName || !contactPerson || !email || !password) {
      return NextResponse.json(
        { error: 'Все поля обязательны для заполнения' },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Пароль должен содержать минимум 6 символов' },
        { status: 400 }
      )
    }

    // Проверка на существование пользователя с таким email
    const existingUser = await prisma.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Пользователь с таким email уже существует' },
        { status: 400 }
      )
    }

    // Генерация уникального номера команды
    let teamNumber: string
    let isTeamNumberUnique = false
    let attempts = 0

    do {
      teamNumber = generateTeamNumber()
      const existingTeam = await prisma.team.findUnique({
        where: { teamNumber }
      })
      isTeamNumberUnique = !existingTeam
      attempts++
    } while (!isTeamNumberUnique && attempts < 10)

    if (!isTeamNumberUnique) {
      return NextResponse.json(
        { error: 'Не удалось сгенерировать уникальный номер команды' },
        { status: 500 }
      )
    }

    // Генерация slug
    let baseSlug = generateSlug(teamName)
    let slug = baseSlug
    let slugAttempts = 0

    // Проверка уникальности slug
    while (slugAttempts < 10) {
      const existingTeam = await prisma.team.findUnique({
        where: { slug }
      })
      
      if (!existingTeam) break
      
      slugAttempts++
      slug = `${baseSlug}-${slugAttempts}`
    }

    // Хеширование пароля
    const passwordHash = await hashPassword(password)

    // Создание команды и пользователя в транзакции
    const result = await prisma.$transaction(async (tx) => {
      // Создание команды
      const team = await tx.team.create({
        data: {
          teamNumber,
          name: teamName,
          slug,
          status: 'ACTIVE',
          contactEmail: email,
          contactPhone: '',
          address: '',
          description: '',
        }
      })

      // Создание пользователя-администратора
      const user = await tx.user.create({
        data: {
          email,
          passwordHash,
          firstName: contactPerson.split(' ')[0] || contactPerson,
          lastName: contactPerson.split(' ').slice(1).join(' ') || '',
          role: 'ADMIN',
          teamId: team.id,
          isActive: true,
        }
      })

      return { team, user }
    })

    // Генерация токена
    const token = generateToken({
      userId: result.user.id,
      email: result.user.email,
      role: result.user.role,
      teamId: result.team.id,
    })

    return NextResponse.json({
      success: true,
      message: 'Команда успешно создана',
      token,
      team: {
        id: result.team.id,
        teamNumber: result.team.teamNumber,
        name: result.team.name,
        slug: result.team.slug,
      },
      user: {
        id: result.user.id,
        email: result.user.email,
        role: result.user.role,
        firstName: result.user.firstName,
        lastName: result.user.lastName,
      }
    })

  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}