import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const teamSlug = searchParams.get('team')
    const masterId = searchParams.get('master')
    const date = searchParams.get('date')

    if (!teamSlug) {
      return NextResponse.json(
        { error: 'Параметр team обязателен' },
        { status: 400 }
      )
    }

    // Поиск команды
    const team = await prisma.team.findUnique({
      where: { slug: teamSlug }
    })

    if (!team) {
      return NextResponse.json(
        { error: 'Команда не найдена' },
        { status: 404 }
      )
    }

    // Построение фильтров
    const where: any = {
      master: {
        teamId: team.id
      }
    }

    if (masterId) {
      where.masterId = masterId
    }

    if (date) {
      const startOfDay = new Date(date)
      startOfDay.setHours(0, 0, 0, 0)
      const endOfDay = new Date(date)
      endOfDay.setHours(23, 59, 59, 999)

      where.startTime = {
        gte: startOfDay,
        lte: endOfDay
      }
    }

    // Получение записей
    const bookings = await prisma.booking.findMany({
      where,
      include: {
        master: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            specialization: true,
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true,
          }
        },
        client: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            email: true,
          }
        }
      },
      orderBy: {
        startTime: 'asc'
      }
    })

    return NextResponse.json({
      success: true,
      bookings
    })

  } catch (error) {
    console.error('Get bookings error:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      teamSlug,
      masterId,
      serviceId,
      clientName,
      clientPhone,
      clientEmail,
      startTime,
      notes
    } = body

    // Валидация обязательных полей
    if (!teamSlug || !masterId || !serviceId || !clientName || !clientPhone || !startTime) {
      return NextResponse.json(
        { error: 'Все обязательные поля должны быть заполнены' },
        { status: 400 }
      )
    }

    // Поиск команды
    const team = await prisma.team.findUnique({
      where: { slug: teamSlug }
    })

    if (!team) {
      return NextResponse.json(
        { error: 'Команда не найдена' },
        { status: 404 }
      )
    }

    // Проверка мастера
    const master = await prisma.master.findFirst({
      where: {
        id: masterId,
        teamId: team.id
      }
    })

    if (!master) {
      return NextResponse.json(
        { error: 'Мастер не найден' },
        { status: 404 }
      )
    }

    // Проверка услуги
    const service = await prisma.service.findFirst({
      where: {
        id: serviceId,
        teamId: team.id
      }
    })

    if (!service) {
      return NextResponse.json(
        { error: 'Услуга не найдена' },
        { status: 404 }
      )
    }

    // Проверка времени записи
    const bookingStartTime = new Date(startTime)
    const bookingEndTime = new Date(bookingStartTime.getTime() + service.duration * 60000)

    // Проверка на конфликт времени
    const conflictingBooking = await prisma.booking.findFirst({
      where: {
        masterId,
        status: {
          in: ['CONFIRMED', 'PENDING']
        },
        OR: [
          {
            startTime: {
              lt: bookingEndTime
            },
            endTime: {
              gt: bookingStartTime
            }
          }
        ]
      }
    })

    if (conflictingBooking) {
      return NextResponse.json(
        { error: 'На это время уже есть запись' },
        { status: 409 }
      )
    }

    // Поиск или создание клиента
    let client = await prisma.client.findFirst({
      where: {
        phone: clientPhone,
        teamId: team.id
      }
    })

    if (!client) {
      const nameParts = clientName.split(' ')
      client = await prisma.client.create({
        data: {
          firstName: nameParts[0] || clientName,
          lastName: nameParts.slice(1).join(' ') || '',
          phone: clientPhone,
          email: clientEmail || '',
          teamId: team.id
        }
      })
    }

    // Создание записи
    const booking = await prisma.booking.create({
      data: {
        masterId,
        serviceId,
        clientId: client.id,
        startTime: bookingStartTime,
        endTime: bookingEndTime,
        status: 'PENDING',
        notes: notes || '',
        totalPrice: service.price
      },
      include: {
        master: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            specialization: true,
          }
        },
        service: {
          select: {
            id: true,
            name: true,
            duration: true,
            price: true,
          }
        },
        client: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            email: true,
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Запись успешно создана',
      booking
    })

  } catch (error) {
    console.error('Create booking error:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}