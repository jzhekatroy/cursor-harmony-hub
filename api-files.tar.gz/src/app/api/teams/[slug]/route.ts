import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(
  request: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const { slug } = params

    if (!slug) {
      return NextResponse.json(
        { error: 'Slug команды обязателен' },
        { status: 400 }
      )
    }

    // Поиск команды со всей необходимой информацией
    const team = await prisma.team.findUnique({
      where: { slug },
      include: {
        masters: {
          where: { isActive: true },
          select: {
            id: true,
            firstName: true,
            lastName: true,
            specialization: true,
            experience: true,
            description: true,
            avatar: true,
          }
        },
        services: {
          where: { isArchived: false },
          select: {
            id: true,
            name: true,
            description: true,
            duration: true,
            price: true,
            category: true,
          },
          orderBy: { name: 'asc' }
        }
      }
    })

    if (!team) {
      return NextResponse.json(
        { error: 'Команда не найдена' },
        { status: 404 }
      )
    }

    if (team.status === 'DISABLED') {
      return NextResponse.json(
        { error: 'Команда временно недоступна' },
        { status: 403 }
      )
    }

    // Группировка услуг по категориям
    const servicesByCategory = team.services.reduce((acc: any, service) => {
      const category = service.category || 'Другие услуги'
      if (!acc[category]) {
        acc[category] = []
      }
      acc[category].push(service)
      return acc
    }, {})

    return NextResponse.json({
      success: true,
      team: {
        id: team.id,
        name: team.name,
        slug: team.slug,
        description: team.description,
        address: team.address,
        contactPhone: team.contactPhone,
        contactEmail: team.contactEmail,
        workingHours: team.workingHours,
        masters: team.masters,
        services: team.services,
        servicesByCategory
      }
    })

  } catch (error) {
    console.error('Get team error:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}